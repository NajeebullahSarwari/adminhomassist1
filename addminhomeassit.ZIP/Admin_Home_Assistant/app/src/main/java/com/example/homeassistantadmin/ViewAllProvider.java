package com.example.homeassistantadmin;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;


public class ViewAllProvider extends AppCompatActivity {
    Button vteacher,vmechnic,vplumber,vcarpenter,velectrician,vengineer;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_all_provider);


        vteacher=findViewById(R.id.btnvteacher);
        vmechnic=findViewById(R.id.btnvmechanic);
        vplumber=findViewById(R.id.btnvplumber);
        vcarpenter=findViewById(R.id.btnvcarpenter);
        velectrician=findViewById(R.id.btnvelectrician);
        vengineer=findViewById(R.id.btnvengineer);
        vteacher.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(ViewAllProvider.this, ItemsActivity.class);
                startActivity(i);
            }
        });
        vmechnic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(ViewAllProvider.this,MechanicViewItemActivity.class);
                startActivity(i);
            }
        });

        vplumber.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(ViewAllProvider.this,PlumberViewItemActivity.class);
                startActivity(i);
            }
        });
        vcarpenter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(ViewAllProvider.this,CarpenterViewItemActivity.class);
                startActivity(i);
            }
        });

        velectrician.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(ViewAllProvider.this,ElectricianViewItemActivity.class);
                startActivity(i);
            }
        });

        vengineer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(ViewAllProvider.this,EngineerViewItemActivity.class);
                startActivity(i);
            }
        });
    }
}
