package com.example.homeassistantadmin;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.os.Bundle;

public class AddAllProvider extends AppCompatActivity {
    Button teacher,mechanic,plumber,carpanter,electrician,engineer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_all_provider);

        teacher=findViewById(R.id.btnaddteacher);
        mechanic=findViewById(R.id.btnaddmechnic);
        plumber=findViewById(R.id.btnaddplumber);
        carpanter=findViewById(R.id.btnaddcarpenter);
        electrician=findViewById(R.id.btnaddelectrician);
        engineer=findViewById(R.id.btnaddengineer);
        teacher.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(AddAllProvider.this, UploadActivity.class);
                startActivity(i);
            }
        });
        mechanic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(AddAllProvider.this,MechanicUpload.class);
                startActivity(i);
            }
        });
        plumber.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(AddAllProvider.this,PlumberUpload.class);
                startActivity(i);

            }
        });

        carpanter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(AddAllProvider.this,CarpenterUpload.class);
                startActivity(i);
            }
        });
        electrician.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(AddAllProvider.this,ElectricianUpload.class);
                startActivity(i);
            }
        });
       engineer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(AddAllProvider.this,EngineerUpload.class);
                startActivity(i);
            }
        });



    }
}
